#coisado

Description
Just a package to really learn, hence the name

##Instalation

Use the package manager, the pip to install coisado

```bash
pip install coisado
```
##Usage
```
python
from coisado import coisado1.py
```

## Author

Júlio Rufino

## License
[MIT](https://choosealicense.com/license/mit)
